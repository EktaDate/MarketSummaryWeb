from URLExtractor import GetData
from TextExtractor import GetText
from SentenceRank import Summary
import pandas as pd
import datetime
import csv
import numpy as np
import pyodbc
import time
import json

server = 'mrsmasteksql.database.windows.net'
database = 'mrsProspectData'
username = 'sysadmin'
password = 'Mastek491$'
driver= '{SQL Server}'
    
exclude=['twitter','glassdoor','youtube','wordpress','facebook','wikipedia','play.google','nasdaq']
startTime_Main = datetime.datetime.now().strftime('%H:%M:%S')
urls=GetData()
notallowed=[]
summarylist=[]
summaryDict={}
print("---START TIME %s ---" % startTime_Main)
a=0
for url in urls:
    a+=1
    if any (s in url[1] for s in exclude):
        #print("Not allowed -",url)
        notallowed.append(url)
    else:
        try:
            article=GetText(url[1])
        except:
            continue
        if not article.startswith("ERROR"):
            print("fetching summary for - ",url[1])
            summary=Summary(article)
        else:
            summary=article

        pdate=datetime.datetime.now().strftime("%m-%d-%Y %H:%M:%S")
        suma=summary.replace('\'',' ')
        cs='DRIVER='+driver+';SERVER='+server+';PORT=1433;DATABASE='+database+';UID='+username+';PWD='+ password
        cnInsert = pyodbc.connect(cs, autocommit=True)
        cursor1 = cnInsert.cursor()
        print(pdate)
        cursor1.execute("insert ProspectSummary(Summary,url,PROSPECTDATAID) values('"+str(suma)+"','"+str(url[1])+"','"+str(url[0])+"');")
        cursor1.execute("update ProspectData set IsProcessed='True', DATAPROCESSEDDATE='"+pdate+"' WHERE ID='"+str(url[0])+"';")
            
        summarylist.append(summary)
        summaryDict[url]=summary
        #print(a)
        print("---TIME %s ---" % (datetime.datetime.now().strftime('%H:%M:%S')))
                    
        
print("FINAL TIME --- %s  START TIME %s ---" % (datetime.datetime.now().strftime('%H:%M:%S') % startTime_Main))
    